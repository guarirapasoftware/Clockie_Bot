# config.py
from pytz import timezone

TOKEN = "7942178752:AAEwEYLd4Ml5mNH4jJjlgpX3Ln42s05SA_M"
TIMEZONE = timezone("Europe/Moscow")